pcall(function()
	if isfolder("Exunys Developer/Aimbot") then
		delfolder("Exunys Developer/Aimbot")
	end
end)
